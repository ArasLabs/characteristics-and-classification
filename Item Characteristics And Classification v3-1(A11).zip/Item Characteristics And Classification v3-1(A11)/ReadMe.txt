
Version:
--------
v3-1A11  (March 2016) - grid handling and edit mode fixes. Tested on Aras 11SP5

v3-0A11  (March 2015) - works on Aras 10SP4 and Aras 11 only !!!
- changed all programmed grids to dojo grids (tree and flat lists on Part Search form)

- on "Part Search" added option "Show All Charateristics"  - if not set only the ones of selected class are listed for input
- on "Part Search" made option "Match Selected Item Class" active - if changed, it will trigger "RunSearch"
- on "Part Search" changed wild card hint to blue text



Sample Part classification hierarchy
------------------------------------
the excel file "PartClass&Chars-Sample Data.xlsx" contains AML comands in various worksheets to build up a class hierarchy with some charactristics connected.
Use nash or AML-studio to import the data.


Description (Package Utilities)
------------
Provides generic classification to Part items based on a hierarchical class structure.
- Characteristics are added to a part item according to its classification.
- This is an extension to standard item properties.
- The mechanism of classification trees and characteristic could be extended to be applied to any item type in Aras Innovator (customization), this version of the solution, however, only adds this feature to item type �Part�

Why
- Some industries can benefit from a generic classification. i.e. Electric components industry.
- Searches can be improved by having a classification hierarchical path.


Installation Steps
------------------
use package import utility to import packages in this sequence  (logon as "admin" and use option "merge")

	0-Other Dependent Packages
		0_Common Utitltites
		1_Common Grid Utitltites

	1_Item Characteristics And Classification

	2_import - PLM extensions

	3_import Data Items

	4-Configuration Data


	5_CodeTreeOverlays
		Copy contents of "Code Tree Overlay" to your code tree of your Aras installation


	(optional) SetPackageVersion  - will fail, if "Package Utitlties" are not in your Aras system



Only the "Part Classification (Root)" is imported as data item.
You must add your own Class Hierarchy a chatacteristics on each level, as needed. Refer to documentation.


Dependencies
------------
- com.aras.innovator.solution.PLM must be present


available as Community Project
------------------------------
Yes


Version History:
----------------
r1-3  (Dec 2012)
      Improved display of Characteristics within Item Class structure.

v2-0  (May 2013)
  - Added "Characteristic Class" column to "Part Item Characteristic Value" and Search Parameters grids

  - Add "API" Methods to be called from integrations to get and save Item Characteristic Values

     + ItemCharacteristicGetAllOfItems
       ==> returns a collection of Items with relationships to its Item Characteristic Values

     + ItemCharacteristicSaveToItem
       ==> Saves a defined item's properties and its characteristic values defined in item context (with relationships)
       ==> If a characteristic is not registered on the item, it will add it.
       ==> Error handling to check for valid characteristic IDs or Names is done.
       ==> Only the <display_value> must be provided for characteristics. (like a user would input)
       ==> Item can be locked (the �update� action will be used) or unlocked (the �edit� action will be used. User must have permission to lock)

       The key properties for writing a value to characteristics are:
         Source ID (of Part Item),
         Characteristic ID or Characteristic Name,
         Characteristic Class ID or Class Name*  

         *These you can retrieve with the method �ItemCharacteristicGetOfClassDown� by providing the Name or ID
          of the of the �root� Item class of the classification hierarchy.


     + ItemCharacteristicGetOfClassDown
       ==> Gets the Characteristics of a specified Item Class (option to include the ones on Sub Classes)

     + ItemCharacteristicGetOfClassUp
       ==> Gets the Characteristics of a specified Item Class up to the root of the Item Class Hierarchy



Notice of Liability
-------------------
The information contained in this document and the import packages are distributed on an "As Is" basis, 
without warranty of any kind, express or implied, including, but not limited to, the implied warranties 
of merchantability and fitness for a particular purpose or a warranty of non-infringement. Aras shall have 
no liability to any person or entity with respect to any loss or damage caused or alleged to be caused 
directly or indirectly by the information contained in this document or by the software or hardware products 
described herein.

