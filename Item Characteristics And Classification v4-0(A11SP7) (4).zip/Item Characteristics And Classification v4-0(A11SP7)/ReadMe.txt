
Notice of Liability
-------------------
The information contained in this document and the import packages are distributed on an "As Is" basis, 
without warranty of any kind, express or implied, including, but not limited to, the implied warranties 
of merchantability and fitness for a particular purpose or a warranty of non-infringement. Aras shall have 
no liability to any person or entity with respect to any loss or damage caused or alleged to be caused 
directly or indirectly by the information contained in this document or by the software or hardware products 
described herein.

---------------------------------------
Item Characteristics And Classification
---------------------------------------

Compatibility
-------------
Developed for "Aras Innovator 11SP7" and up
briefly tested on "Aras Innovator 11SP5"


Version:
--------
v4-0A11SP7 (December 2016)
- now based on new Common Grid Utiltities v3-1 that are loaded from the CodeTree (rather than with form events)
- handling of modal dialogs compatible to Chrome browser..
- Grid configurations from files in CodeTree  (no longer as an Admin option)
- Results grid lists "current" version of items only
- changed character for number ranges from '-' to ':'  (now negative numbers can be used with ranges)
- Multiple classifications (group) can be configured and mapped to an item type. 
  (i.e. Part can have to groups: 1 for Technical and 1 for Quality) (other itemTypes like Document or your own can be extended with their own characteristics group)
   + logic in place that configuration add/updates the properties on NULL relationship that hold the values
   + this will maintain constient use of properties.  Relevant server and grid events are also aded
- added "Admin Guide" documentation


Sample Part classification hierarchy
------------------------------------
This can now be loaded via an optional import step (script)


Description (Item Characteristics And Classification)
------------
Provides generic classification to ItemTypes based on a hierarchical class structure.
- Characteristics are added to an item according to its configured classification.
- This is an extension to standard item properties.

Why
- Some industries can benefit from a generic classification. i.e. Electric components industry.
- Searches can improve by having a classification hierarchical path.


Installation Steps
------------------
use package import utility to import packages in this sequence  (logon as "admin" and use option "merge")

	0-Other Dependent Packages
		0_Common Utitltites
		1_Common Grid Utitltites

	1_Item Characteristics n Classification
	1_Item Characteristics n Classif-Post  (if you have a previous version loaded, this step is a MUST)

	2_import - PLM extensions

	3_import Data Items


	4_CodeTreeOverlays (Solution)
	5_CodeTreeOverlays (common Grid Utilities 3-1)
		Copy contents of "Code Tree Overlay" to your code tree of your Aras installation


	(optional) 9_import Sample ClassTrees


	(optional) SetPackageVersion  - will fail, if "Package Utitlties" are not in your Aras system


Only the "Part Classification (Root)" is imported as data item if sample ClassTrees are not imported.
You can add your own Class Hierarchy a characteristics on each level, as needed. Refer to documentation.


Dependencies
------------
- com.aras.innovator.solution.PLM must be present
- Common Utitltites  (Helper Methods)
- Common Grid Utitltites (Helper Methods)


available as Community Project
------------------------------
Yes


Version History:
----------------
v3-1A11  (March 2016) - grid handling and edit mode fixes. Tested on Aras 11SP5

v3-0A11  (March 2015) - works on Aras 10SP4 and Aras 11 only !!!
- changed all programmed grids to dojo grids (tree and flat lists on Part Search form)

- on "Part Search" added option "Show All Charateristics"  - if not set only the ones of selected class are listed for input
- on "Part Search" made option "Match Selected Item Class" active - if changed, it will trigger "RunSearch"
- on "Part Search" changed wild card hint to blue text

v2-0  (May 2013)
  - Added "Characteristic Class" column to "Part Item Characteristic Value" and Search Parameters grids

  - Add "API" Methods to be called from integrations to get and save Item Characteristic Values

     + ItemCharacteristicGetAllOfItems
       ==> returns a collection of Items with relationships to its Item Characteristic Values

     + ItemCharacteristicSaveToItem
       ==> Saves a defined item's properties and its characteristic values defined in item context (with relationships)
       ==> If a characteristic is not registered on the item, it will add it.
       ==> Error handling to check for valid characteristic IDs or Names is done.
       ==> Only the <display_value> must be provided for characteristics. (like a user would input)
       ==> Item can be locked (the �update� action will be used) or unlocked (the �edit� action will be used. User must have permission to lock)

       The key properties for writing a value to characteristics are:
         Source ID (of Part Item),
         Characteristic ID or Characteristic Name,
         Characteristic Class ID or Class Name*  

         *These you can retrieve with the method �ItemCharacteristicGetOfClassDown� by providing the Name or ID
          of the of the �root� Item class of the classification hierarchy.


     + ItemCharacteristicGetOfClassDown
       ==> Gets the Characteristics of a specified Item Class (option to include the ones on Sub Classes)

     + ItemCharacteristicGetOfClassUp
       ==> Gets the Characteristics of a specified Item Class up to the root of the Item Class Hierarchy


r1-3  (Dec 2012)
      Improved display of Characteristics within Item Class structure.

