
Version:
--------
r1-3  (Dec 2012)
      Improved display of Characteristics within Item Class structure.


Description (Package Utilities)
------------
Provides generic classification to Part items based on a hierarchical class structure.
- Characteristics are added to a part item according to its classification.
- This is an extension to standard item properties.
- The mechanism of classification trees and characteristic could be extended to be applied to any item type in Aras Innovator (customization), this version of the solution, however, only adds this feature to item type �Part�

Why
- Some industries can benefit from a generic classification. i.e. Electric components industry.
- Searches can be improved by having a classification hierarchical path.


Dependencies
------------
None


available as Community Project
------------------------------
Yes



Notice of Liability
-------------------
The information contained in this document and the import packages are distributed on an "As Is" basis, 
without warranty of any kind, express or implied, including, but not limited to, the implied warranties 
of merchantability and fitness for a particular purpose or a warranty of non-infringement. Aras shall have 
no liability to any person or entity with respect to any loss or damage caused or alleged to be caused 
directly or indirectly by the information contained in this document or by the software or hardware products 
described herein.

